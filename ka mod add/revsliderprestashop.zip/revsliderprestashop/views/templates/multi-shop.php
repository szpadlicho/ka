<?php
/**
 * 2016 Revolution Slider
 *
 *  @author    SmatDataSoft <support@smartdatasoft.com>
 *  @copyright 2016 SmatDataSoft
 *  @license   private
 *  @version   5.1.3
 *  International Registered Trademark & Property of SmatDataSoft
 */

echo '<input type="hidden" name="id_shop" id="sds_rev_id_shop" value="' . Context::getcontext()->shop->id . '">';
