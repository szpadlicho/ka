<?php
class PremiumCore extends CustomerCore {
    
    // function __construct()
    // {
        // parent::__construct();
        
        // $this->initContent();
    // }
    // public function initContent(){
        // //create your variable
        // self::$smarty->context->smarty->assign('one', 'two');

        // //call original method, to maintain default behaviour:
        // return parent::iniContent();
        // return $this->display(__FILE__, 'premiumgroup.tpl');
    // }
}
?>