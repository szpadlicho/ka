// $(function(){
    // var slp = $(".fb-social").css('left');
    // $(".fb-social").hover(function(b){
        // var a=$(this);
        // a.stop().animate({left:0})
    // },function(b){
        // var a=$(this);
        // a.stop().animate({left: slp});
    // });
// });

// $(function(){
    // var slp = $( '.fb-social' ).css('left');
    // $( '.fb-social' ).on( 'click', function() {
        // console.log( slp );
        // var s = $(this);
        // var c = s.css( 'left' );
        // if ( c == slp) {
            // s.stop().animate({ left: 0 })
        // } else{
            // s.stop().animate({left: slp});
        // }
    // });
// });

// $(function(){
    // setTimeout(function() {
        // var wc = $( '.fb-page' ).width();
        // var wb = $( 'body' ).width();
        // $( '.fb-lable' ).append(wc+' ');
        // $( '.fb-lable' ).append(wb+' ');
        // alert(wc+' '+wb);
    // }, 9000);
// });