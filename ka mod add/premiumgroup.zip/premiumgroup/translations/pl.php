<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{facebookslider}prestashop>facebookslider_790da20b332e3b579149c6c55445fe13'] = 'Facebook Slider';
$_MODULE['<{facebookslider}prestashop>facebookslider_ef9a8550973d5c5a4462c619b2e87a6d'] = 'Facebook Slider dla twojego fanpage';
$_MODULE['<{facebookslider}prestashop>facebookslider_bb8956c67b82c7444a80c6b2433dd8b4'] = 'Jesteś pewien że chcesz usunąć ten moduł?';
$_MODULE['<{facebookslider}prestashop>facebookslider_3585ffddb1cb692156a3eb9f1fc5ab45'] = 'Musisz skonfigurować ten moduł';
$_MODULE['<{facebookslider}prestashop>setting_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{facebookslider}prestashop>setting_851eca6da6af1652ab2288b6b86ba0b8'] = 'Adres strony';
$_MODULE['<{facebookslider}prestashop>setting_7a1920d61156abc05a60135aefe8bc67'] = 'Domyślnie';
$_MODULE['<{facebookslider}prestashop>setting_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nie';
$_MODULE['<{facebookslider}prestashop>setting_93cba07454f06a4a960172bbd6e2a435'] = 'Tak';
$_MODULE['<{facebookslider}prestashop>setting_945d5e233cf7d6240f6b783b36a374ff'] = 'Lewa';
$_MODULE['<{facebookslider}prestashop>setting_92b09c7c48c520c3c55e497875da437c'] = 'Prawa';
$_MODULE['<{facebookslider}prestashop>setting_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{facebookslider}prestashop>setting_8b87e5be27f03a0175238964e714a362'] = 'Etykieta';
$_MODULE['<{facebookslider}prestashop>setting_eec6c4bdbd339edf8cbea68becb85244'] = 'Wysokość';
$_MODULE['<{facebookslider}prestashop>setting_32954654ac8fe66a1d09be19001de2d4'] = 'Szerokość';
$_MODULE['<{facebookslider}prestashop>setting_49b3d57c9699059f01fdd9cd2f513ec7'] = 'Pozycja na osi Y';
$_MODULE['<{facebookslider}prestashop>setting_fc88379b3f248c764f9a94f3af47e53e'] = 'Pozycja na osi X';
$_MODULE['<{facebookslider}prestashop>setting_4c3880bb027f159e801041b1021e88e8'] = 'Metoda';
$_MODULE['<{facebookslider}prestashop>setting_138d883c786e2c40343f5b0e666a3099'] = 'Mały nagłówek';
$_MODULE['<{facebookslider}prestashop>setting_39f2e45ad10ecda807819a06b99b3cc7'] = 'Pokazuj posty';
$_MODULE['<{facebookslider}prestashop>setting_c8bda32bf401bbb2c80a8d5771fbcd65'] = 'Pokazuj wiadomości';
$_MODULE['<{facebookslider}prestashop>setting_2b9e59284cd1bf3356663afab21a432c'] = 'Pokazuj wydarzenia';
$_MODULE['<{facebookslider}prestashop>setting_87b739c802f94cbb282f7836f1751a6b'] = 'Pokazuj zdjęcia polubień';
$_MODULE['<{facebookslider}prestashop>setting_61a62a253d7ba13a470227fa7e646f96'] = 'Ukryj zdjęcie w tle';
$_MODULE['<{facebookslider}prestashop>setting_3c680d9258b6ed9d5c383929cee08e89'] = 'Krawędź strony';
$_MODULE['<{facebookslider}prestashop>setting_c276181d068e5add80a6334d6aa437ae'] = 'Pokaż na urządzeniach mobilnych';
$_MODULE['<{facebookslider}prestashop>setting_7231d1aa9afc9b0899df2e6d5d8f7e3a'] = 'Max szerokość ekranu mobilnego';

