<?php

abstract class OauthGrantType
{
    const CLIENT_CREDENTIAL = 'client_credentials';
}