<?php

interface AuthType
{

    /**
     * @return array
     */
    public function getHeaders();


}