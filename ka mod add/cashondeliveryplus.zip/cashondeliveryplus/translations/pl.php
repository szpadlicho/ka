<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cashondeliveryplus}prestashop>cashondeliveryplus_8a45b3ee3b9de906fcfcae27bc6e58ee'] = 'Za pobraniem';
$_MODULE['<{cashondeliveryplus}prestashop>cashondeliveryplus_7a3ef27eb0b1895ebf263ad7dd949fb6'] = 'Akceptujemy płatności za pobraniem';
$_MODULE['<{cashondeliveryplus}prestashop>validation_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Przesyłka';
$_MODULE['<{cashondeliveryplus}prestashop>validation_0c25b529b4d690c39b0831840d0ed01c'] = 'Podsumowanie zamówienia';
$_MODULE['<{cashondeliveryplus}prestashop>validation_d538c5b86e9a71455ba27412f4e9ab51'] = 'Płatność przy odbiorze';
$_MODULE['<{cashondeliveryplus}prestashop>validation_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Wybrałeś płatność przy odbiorze jako metodę płatności.';
$_MODULE['<{cashondeliveryplus}prestashop>validation_e2867a925cba382f1436d1834bb52a1c'] = 'Całkowita wartość twojego zamówienia wynosi';
$_MODULE['<{cashondeliveryplus}prestashop>validation_1f87346a16cf80c372065de3c54c86d9'] = '(brutto)';
$_MODULE['<{cashondeliveryplus}prestashop>validation_75e6b17f1065160aea798ba661ccb1f1'] = 'Kwota ta zawiera dodatek za wybraną metodę płatności +';
$_MODULE['<{cashondeliveryplus}prestashop>validation_0881a11f7af33bc1b43e437391129d66'] = 'Proszę potwierdzić zamówienie klikając poniżej';
$_MODULE['<{cashondeliveryplus}prestashop>validation_569fd05bdafa1712c4f6be5b153b8418'] = '« Wstecz';
$_MODULE['<{cashondeliveryplus}prestashop>validation_46b9e3665f187c739c55983f757ccda0'] = 'Potwierdzam zamówienie';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_2e2117b7c81aa9ea6931641ea2c6499f'] = 'Twoje zamówienie w';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_75fbf512d744977d62599cc3f0ae2bb4'] = 'zostało zakończone.';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Wybrałaś/eś płatność przy odbiorze.';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_e6dc7945b557a1cd949bea92dd58963e'] = 'Twoje zamówienie zostanie wkrótce wysłane.';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_0db71da7150c27142eef9d22b843b4a9'] = 'W razie pytań lub wątpliwości, prosimy o kontakt z';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_64430ad2835be8ad60c59e7d44e4b0b1'] = 'biurem obsługi klienta';
$_MODULE['<{cashondeliveryplus}prestashop>payment_b7ada96a0da7ee7fb5371cca0b036d5c'] = 'Płatność za pobraniem';
$_MODULE['<{cashondeliveryplus}prestashop>payment_536dc7424180872c8c2488ae0286fb53'] = 'Płacisz za towar przy dostawie';
