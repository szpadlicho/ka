<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{cashondeliveryplus}prestashop>cashondeliveryplus_8a45b3ee3b9de906fcfcae27bc6e58ee'] = 'Comptant à la livraison  (COD+)';
$_MODULE['<{cashondeliveryplus}prestashop>cashondeliveryplus_7a3ef27eb0b1895ebf263ad7dd949fb6'] = 'Accepte le paiement lors de la livraison';
$_MODULE['<{cashondeliveryplus}prestashop>validation_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Frais d\'expédition';
$_MODULE['<{cashondeliveryplus}prestashop>validation_0c25b529b4d690c39b0831840d0ed01c'] = 'Récapitulatif de commande';
$_MODULE['<{cashondeliveryplus}prestashop>validation_d538c5b86e9a71455ba27412f4e9ab51'] = 'Paiement comptant à la livraison';
$_MODULE['<{cashondeliveryplus}prestashop>validation_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Vous avez choisi de régler comptant lors de la livraison de la commande.';
$_MODULE['<{cashondeliveryplus}prestashop>validation_e2867a925cba382f1436d1834bb52a1c'] = 'Le montant total de votre commande s\'élève à';
$_MODULE['<{cashondeliveryplus}prestashop>validation_1f87346a16cf80c372065de3c54c86d9'] = 'TTC';
$_MODULE['<{cashondeliveryplus}prestashop>validation_0881a11f7af33bc1b43e437391129d66'] = 'Merci de confirmer votre commande en cliquant sur \"Je confirme ma commande\"';
$_MODULE['<{cashondeliveryplus}prestashop>validation_569fd05bdafa1712c4f6be5b153b8418'] = 'Autres moyens de paiement';
$_MODULE['<{cashondeliveryplus}prestashop>validation_46b9e3665f187c739c55983f757ccda0'] = 'Je confirme ma commande';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_2e2117b7c81aa9ea6931641ea2c6499f'] = 'Votre commande sur';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_75fbf512d744977d62599cc3f0ae2bb4'] = 'est bien enregistrée.';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_8861c5d3fa54b330d1f60ba50fcc4aab'] = 'Vous avez choisi le paiement lors de la livraison.';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_e6dc7945b557a1cd949bea92dd58963e'] = 'Votre commande vous sera envoyée très prochainement.';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_0db71da7150c27142eef9d22b843b4a9'] = 'Pour toute question ou information complémentaire merci de contacter notre';
$_MODULE['<{cashondeliveryplus}prestashop>confirmation_64430ad2835be8ad60c59e7d44e4b0b1'] = 'support client';
$_MODULE['<{cashondeliveryplus}prestashop>payment_b7ada96a0da7ee7fb5371cca0b036d5c'] = 'Payer comptant à la livraison';
$_MODULE['<{cashondeliveryplus}prestashop>payment_536dc7424180872c8c2488ae0286fb53'] = 'Vous payez lors de la livraison de votre commande';
